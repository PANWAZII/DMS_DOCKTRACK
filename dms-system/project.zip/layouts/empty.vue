<template>
    <nuxt/>
</template>