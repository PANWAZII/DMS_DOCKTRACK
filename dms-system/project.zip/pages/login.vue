<template>
  <v-app>
    <v-main>
      <v-container class="fill-height justify-center">
        <v-card elevation="1" height="700" width="900">
          <v-row align="center" justify="center" dense>
            <v-col cols="12" sm="8" md="6" lg="6">
              <v-img
                class="mt-15 mb-5"
                :src="require('../assets/logo.png')"
                contain
                height="200"
              >
              </v-img>
              <v-card-text>
                <v-form>
                  <v-text-field
                    label="Enter your email"
                    name="Email"
                    prepend-inner-icon="mdi-mail"
                    type="email"
                    class="rounded-1"
                    outlined
                    v-model="form.email"
                  >
                  </v-text-field>
                  <v-text-field
                    label="Enter your password"
                    name="password"
                    prepend-inner-icon="mdi-lock"
                    type="password"
                    class="rounded-1"
                    outlined
                    v-model="form.pass"
                  >
                  </v-text-field>
                  <v-btn
                    class="rounded-1"
                    color="#056839"
                    x-large
                    block
                    @click="login"
                  >
                    <div class="white--text font-weight-bold">Login</div>
                  </v-btn>
                </v-form>
                <a href="#" class="float-right mt-5 font-weight-bold"
                  >Sign Up</a
                >
              </v-card-text>
            </v-col>
          </v-row>
        </v-card>
        <!-- {{form.email}}
        {{form.pass}} -->
      </v-container>
    </v-main>
    <!-- <v-snackbar :timeout="4000" v-model="snackbar" absolute bottom center>
      {{ snackbarText }}
    </v-snackbar> -->
  </v-app>
</template>
<script>
export default {
  layout: 'empty',
  middleware: 'login',
  data() {
    return {
      form: {
        email: '',
        pass: '',
      },
    }
  },
  methods: {
    login() {
      this.$fire.auth
        .signInWithEmailAndPassword(this.form.email, this.form.pass)
        .then(async (user) => {
          await this.$store.dispatch('login', user.user)
          this.$router.push('/')
        })

        .catch((err) => {
          console.log(err)
        })
    },

    // logout() {
    //     this.$fire.auth
    //       .signInWithEmailAndPassword(this.form.email, this.form.pass)
    //       .then((user) => {
    //         return this.$store.dispatch('logout')
    //       })
    //       .then(() => {
    //         this.$router.push('/login')
    //       })
    //       .catch((err) => {
    //         console.log(err)
    //       })
    //   },
  },
}
</script>
